﻿using System.ComponentModel.DataAnnotations;

namespace ClientSideValidation.Models
{
    public class Home
    {
        [Required]
        public string name { get; set; }
    }
}
