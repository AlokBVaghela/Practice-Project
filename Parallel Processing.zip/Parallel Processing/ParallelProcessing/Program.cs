﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;

long LoopCount = 10;
long row = 10;
long column = 2;
long[,] array = new long[row,column];

Count c = new();
var stopwatch = new Stopwatch();
stopwatch.Start();
for (c.i = 0; c.i < LoopCount; c.i++)
{
    Count.PrintNumber(c.i);
}
stopwatch.Stop();
long WithoutParallelLoop = stopwatch.ElapsedTicks;

stopwatch.Restart();
c.i = 0;
Parallel.For(c.i, LoopCount - 1, index => { Count.PrintNumber(index); });
stopwatch.Stop();
long ParallelLoop = stopwatch.ElapsedTicks;

stopwatch.Restart();
c.i = 0;
Parallel.For(c.i, LoopCount-1, new ParallelOptions() { MaxDegreeOfParallelism = Environment.ProcessorCount }, index => { Count.PrintNumber(index); });
stopwatch.Stop();
long ParallelLoopWithProcessorCount = stopwatch.ElapsedTicks;

long count = 0;
for (int i = 0; i < row; i++)
{
    for (int j = 0; j < column; j++, count++)
    {
        array[i, j] = count;
    }
}
stopwatch.Restart();
for (long i = 0; i < row; i++)
{
    for (long j = 0; j < column; j++)
    {
        Count.PrintArray(array[i, j]);

        Console.Write(" ");
    }

    Console.WriteLine();
}
stopwatch.Stop();
long TwoDArray = stopwatch.ElapsedTicks;

//Flattening Array
long[] array1 = new long[row*column];
count = 0;
for (int i = 0; i < row; i++)
{
    for (int j = 0; j < column; j++, count++)
    {
        array1[count] = array[i, j];
    }
}
stopwatch.Restart();
for (long i = 0; i < array1.Length; i += column)
{
    for (long j = 0; j < column; j++)
    {
        Count.PrintArray(array1[i + j]);

        Console.Write(" ");
    }

    Console.WriteLine();
}
stopwatch.Stop();
long FlattenedArray = stopwatch.ElapsedTicks;

Console.WriteLine($"Time taken without Parallel Loop : {WithoutParallelLoop} ticks");
Console.WriteLine($"Time taken with Parallel Loop : {ParallelLoop} ticks");
Console.WriteLine($"Time taken with Parallel Loop with MaxDegreeOfParallelism(Processor Count) : {ParallelLoopWithProcessorCount} ticks");
Console.WriteLine($"Time taken for 2D Array : {TwoDArray} ticks");
Console.WriteLine($"Time taken for Flattened Array : {FlattenedArray} ticks");
Console.Read();

class Count
{
    public long i { get; set; }
    public int ProcessorCount { get; set; }

    public static void PrintNumber(long i)
    {
        Console.WriteLine(i);

        Thread.Sleep(500);
    }

    public static void PrintArray(long i)
    {
        Console.Write(i);
    }
}