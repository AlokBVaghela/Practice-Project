﻿namespace ConsoleApp;

partial class Program
{
    static void Main(string[] args)
    {
        HelloFrom("Alok Vaghela");
        HelloFrom1("Alok Vaghela");

        Program1.Hi1("Alok Vaghela");

        Program2.Hi3("Alok Vaghela");
    }

    static partial void HelloFrom(string name);
    static partial void HelloFrom1(string name);

    partial class Program1
    {
        static partial void Hi(string name);

        static public void Hi1(string name)
        {
            Hi(name);
        }
    }
}

partial class Program2
{
    static partial void Hi2(string name);

    static public void Hi3(string name)
    {
        Hi2(name);
    }
}