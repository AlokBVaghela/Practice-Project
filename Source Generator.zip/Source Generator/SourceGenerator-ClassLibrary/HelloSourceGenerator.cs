﻿using Microsoft.CodeAnalysis;

namespace SourceGenerator
{
    [Generator]
    public class HelloSourceGenerator : ISourceGenerator
    {
        public void Execute(GeneratorExecutionContext context)
        {
            // Find the main method
            var mainMethod = context.Compilation.GetEntryPoint(context.CancellationToken);

            //Appending HelloFrom code
            // Build up the source code
            string source = $@"
                using System;

                namespace {mainMethod.ContainingNamespace.ToDisplayString()};
                
                public static partial class {mainMethod.ContainingType.Name}
                {{
                    static partial void HelloFrom(string name) =>
                        Console.WriteLine($""Generator says: Hi from '{{name}}'"");
                        
                    static partial void HelloFrom1(string name) =>
                        Console.WriteLine($""Hello World '{{name}}'"");

                    public static partial class Program1
                    {{
                        static partial void Hi(string name) =>
                            Console.WriteLine($""'{{name}}'"");
                    }}
                }}
            ";
            var typeName = mainMethod.ContainingType.Name;
            // Add the source code to the compilation
            context.AddSource($"{typeName}.g.cs", source);

            string source1 = $@"
                using System;

                namespace {mainMethod.ContainingNamespace.ToDisplayString()};
                
                public static partial class Program2
                {{
                    static partial void Hi2(string name) =>
                            Console.WriteLine($""Welcome '{{name}}'"");
                }}
            ";
            // Add the source code to the compilation
            context.AddSource($"Program2.g.cs", source1);
        }

        public void Initialize(GeneratorInitializationContext context)
        {
            // No initialization required for this one
        }
    }
}